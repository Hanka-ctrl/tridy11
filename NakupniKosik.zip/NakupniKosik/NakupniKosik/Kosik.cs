﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NakupniKosik
{
    internal class Kosik
    {
        private List<PolozkaKosiku> listProduktu;

        public Kosik()
        {
            listProduktu = new List<PolozkaKosiku>();
        }
        public void PridejPolozku(Produkt p, int ks) //dáváme sem celej ten produkt
        {
            PolozkaKosiku nova = new PolozkaKosiku(p, ks);
            listProduktu.Add(nova); //přidá se prostě celá třída položka, takže i kolik kusů to je

        }

        public void OdeberPolozku(Produkt p, int ks) //dáváme sem celej ten produkt
        {
            PolozkaKosiku nova = new PolozkaKosiku(p, ks);
            listProduktu.Remove(nova); //odebere se CELÁ třída položka
        }

        public double CelkCena()
        {
            double celkem = 0;
            foreach (PolozkaKosiku itempolozky in listProduktu) //pro každou položku v košíku
            {
                celkem += itempolozky.CenaCelkem(); //se přečte k "celkem" cenacelkem, což je celková cena té jedné položky
            }
            return celkem;
        }

        public string VypisUctenku()
        {
            string uctenka = "";

            foreach (PolozkaKosiku itempolozky in listProduktu)
            {
                uctenka += itempolozky.produkt.nazev +" "+ itempolozky.ks + "\n"; //"\n" je enter, k účtence basically přidáváme stringy těch věcí
            }
            uctenka += "Celkem: " + CelkCena();  //na konec jenom hodíme celkovou cenu
            return uctenka;

        }

    }
}
