﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NakupniKosik
{
    internal class Produkt
    {
        private string nazev;
        private double cena;

        public Produkt(string _nazev, double _cena)
        {
            nazev = _nazev;
            cena = _cena;

        }

        public double VratCenu()
        {
            return cena;
        }

        public string VratNazev()
        {
            return nazev;
        }
    }
}
