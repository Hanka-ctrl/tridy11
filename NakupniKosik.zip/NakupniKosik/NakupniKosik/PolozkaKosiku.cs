﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NakupniKosik
{
    internal class PolozkaKosiku
    {
        private Produkt produkt;
        private int ks;

        public double CenaCelkem()
        {
            double CelkCena = ks * produkt.VratCenu();
            return CelkCena;
        }

        public PolozkaKosiku(Produkt _produkt, int _ks)
        {
            produkt = _produkt;
            ks = _ks;
        }

        public Produkt VratProdukt()
        {
            return produkt;
        }

        public int VratKus()
        {
            return ks;
        }

    }
}
