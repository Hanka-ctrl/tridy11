﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NakupniKosik
{
    internal class PolozkaKosiku
    {
        public Produkt produkt;
        public int ks;

        public double CenaCelkem()
        {
            double CelkCena = ks * produkt.cena;
            return CelkCena;
        }

        public PolozkaKosiku(Produkt _produkt, int _ks)
        {
            produkt = _produkt;
            ks = _ks;
        }

    }
}
