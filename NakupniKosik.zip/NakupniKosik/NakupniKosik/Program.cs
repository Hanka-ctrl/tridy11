﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NakupniKosik
{
    internal class Program
    {
        static void Main(string[] args)
        { 

            Produkt jahody = new Produkt("Jahody", 120.20);
            Produkt houby = new Produkt("Houby", 70.20);
            Produkt brambory = new Produkt("Brambory", 83.90);    //prostě "vytvoření produktů"


            Kosik kosik = new Kosik(); //vytvoření košíku
            kosik.PridejPolozku(brambory, 20);
            kosik.PridejPolozku(jahody, 10);   //do košíku dáme produkty a jejich množství

            Console.WriteLine(kosik.CelkCena());
            Console.WriteLine(kosik.VypisUctenku());  //výpis hodnot




        }
    }
}
