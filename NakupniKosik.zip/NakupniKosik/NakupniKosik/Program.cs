﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NakupniKosik
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Menu();

            Produkt jahody = new Produkt();
            jahody.nazev = "Jahody";
            jahody.cena = 120.50;

            Produkt houby = new Produkt();
            houby.nazev = "Houby";
            houby.cena = 70.20;

            Produkt brambory = new Produkt();
            brambory.nazev = "Brambory";    
            brambory.cena = 83.90;     //prostě "vytvoření produktů"


            Kosik kosik = new Kosik(); //vytvoření košíku
            kosik.PridejPolozku(brambory, 20);
            kosik.PridejPolozku(jahody, 10);   //do košíku dáme produkty a jejich množství

            Console.WriteLine(kosik.CelkCena());
            Console.WriteLine(kosik.VypisUctenku());  //výpis hodnot




        }

        static void Menu()
        {
            Console.WriteLine("1. Přídání do košíku");
            Console.WriteLine("2. Odebrání z košíku");
            Console.WriteLine("3. Výpis účtenky");
            Console.WriteLine("4. Konec");

        }
    }
}
